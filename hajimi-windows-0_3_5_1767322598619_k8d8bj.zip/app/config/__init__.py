# 配置模块初始化文件
import app.config.settings as settings
from app.config.safety import *
from app.config.persistence import save_settings, load_settings