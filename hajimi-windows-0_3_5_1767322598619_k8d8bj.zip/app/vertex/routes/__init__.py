# This file makes the 'routes' directory a Python package.
from app.vertex.routes import chat_api, models_api